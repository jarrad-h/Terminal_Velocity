<!-- Merge this section into the repo's existing CLAUDE.md, then delete this file. -->

## How we work (read every session)

- **Source of truth:** `docs/spec.md` (what), `docs/decisions.md` (why), `docs/devlog.md` (what happened). Nothing lives only in chat. If a conversation changes the design, the spec changes in the same session.
- **Skills:** `design` for design talk (no code), `milestone` to build requirement IDs (plan → approve → build → test → playtest handover), `playtest` for Jarrad's feedback (bug / tuning / design change). Use them even if Jarrad doesn't name them.
- **Two PCs:** Jarrad switches between two Windows machines. Run the `start` skill at the beginning of every session and `wrap-up` at the end, even if he doesn't name them. Session history doesn't travel between machines; the devlog "Stopped at / Next step" note does.
- **Pinned Godot version:** <!-- fill in during bootstrap, e.g. 4.5-stable --> — both machines must match.
- **Commit** Godot `.uid` files; never commit `.godot/`.
- **Requirement IDs** (F1, C3, D8 …) are stable references. Cite them in commits, tests and devlog entries.
- **Verify, don't guess:** after code changes, run `python tools/check.py` and run the game via the `godot` MCP server to read real runtime errors. "It should work" is not done; GREEN plus a clean run is.
- **Tuning is data:** feel/balance feedback changes JSON in `data/`, not code.
- **Branches:** one per milestone (`m<N>-<slug>`). Merge to `main` only after Jarrad confirms the playtest.
- **Godot 4 only:** `@export`, `@onready`, `await`, `CharacterBody2D`/`Node2D` + custom kinematics, static typing in new code. Physics in `_physics_process`.
- **Review:** run the `godot-reviewer` agent before every playtest handover.
- **Windows:** Jarrad is on Windows; use the Godot *console* executable via `GODOT_PATH` for headless runs so output is captured.
